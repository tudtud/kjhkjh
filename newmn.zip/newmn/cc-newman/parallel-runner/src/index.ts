import * as async from 'async';
import { log } from './log';
import { NewmanCommandImpl } from './NewmanCommand';
import * as yargs from 'yargs';

// Parse command line options
const options = yargs.usage('Usage: -n <numParallelRuns> -e <environmentJsonFileName>').options({
  n: {
    alias: 'numParallelRuns',
    describe: 'Number of parallel runs',
    type: 'number',
    demandOption: true,
  },
  e: {
    alias: 'environment',
    describe: 'Environment json file to load',
    type: 'string',
    default: 'localToStagingSysAdmin.json',
  },
}).argv;

const NUM_ITERATIONS: number = options.n;
const environment = `../../src/policy/env/${options.e}`;

// TODO: externalize these parameters
const bindPolicyPostmanCollection = '../../src/policy/collections/generated/bindRatedPolicy.json';
const editCoveragesPostmanCollection = '../../src/policy/collections/generated/editCoverages.json';

// Define a single path through the postman collections. May include
// multiple newman commands (i.e. postman collections).
const collectionRun = () => {
  new NewmanCommandImpl().execute(bindPolicyPostmanCollection, environment);
  new NewmanCommandImpl().execute(editCoveragesPostmanCollection, environment);
};

// Add the collection runs to an array which will be used to execute the
// tasks in parallel
const parallelTasks = [];
for (let i = 0; i < NUM_ITERATIONS; i++) {
  parallelTasks.push(collectionRun);
}

// Run the Postman collections in parallel
log.info(`Starting parallel run...`);
async.parallel(parallelTasks);
