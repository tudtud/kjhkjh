import { log } from './log';
import * as newman from 'newman';

export interface NewmanCommand {
  execute(postmanCollectionName: string, environment: string): boolean;
}

export class NewmanCommandImpl implements NewmanCommand {
  public execute(postmanCollectionName: string, environment: string): boolean {
    log.info(`START collection ${postmanCollectionName}:`);

    const fs = require('fs');
    fs.access(postmanCollectionName, fs.constants.F_OK, (err: Error) => {
      if (err) {
        log.warn(`${postmanCollectionName} does not exist`);
        return false;
      }
      return true;
    });

    const collectionString = fs.readFileSync(postmanCollectionName).toString();
    const collectionJson = JSON.parse(collectionString);

    const environmentString = fs.readFileSync(environment).toString();
    const environmentJson = JSON.parse(environmentString);

    const runOptions: newman.NewmanRunOptions = {
      collection: collectionJson,
      environment: environmentJson,
      reporters: ['cli','json'],
      reporter: { json : { export : './jsonResults.json' } }
    };

    newman.run(runOptions, (err: Error | null, summary: newman.NewmanRunSummary) => {
      if (err) {
        log.error(`Error during run: ${err}`);
      }
      if (summary) {
        const results = this.createSummary(summary);
        log.info(`Results: ${JSON.stringify(results)}`);
      } else {
        log.error(`No results for run`);
      }

      // See if any of the responses returned an error code
      let hasErrors = false;
      for (const execution of summary.run.failures) {
        const response = execution.error;
        log.info(`Request ${execution.source?.name} returned ${response.message}`);
        if (response.index >= 400) {
          hasErrors = true;
        }
      }
      return !hasErrors;
    });

    return true;
  }

  private createSummary(summary: newman.NewmanRunSummary): any {
    const failures = Array<any>();
    summary.run.failures.forEach((failure: newman.NewmanRunFailure) => {
      failures.push({
        Parent: {
          Name: failure.parent.name,
          Id: failure.parent.id,
        },
        Source: {
          Name: failure.source?.name,
        },
        Error: {
          Message: failure.error.message,
          Test: failure.error.test,
        },
      });
    });

    // Build main object with just the bits needed plus the slimmed down failures
    const result = {};
    Object.assign(result, {
      Collection: {
        Info: {
          Name: summary.collection.name,
          Id: summary.collection.id,
        },
      },
      Run: {
        Stats: {
          Requests: summary.run.stats.requests,
          Assertions: summary.run.stats.assertions,
        },
        Failures: failures,
      },
    });
    return result;
  }
}
