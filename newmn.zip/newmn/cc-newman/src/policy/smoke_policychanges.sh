#!/usr/bin/env bash
: "${1?"Usage: $0 env_json_path"}"
ENV_PATH=$1

set -euo pipefail

pushd ./src/policy || exit

echo "Running Policy Change Events Collection - PA"
../../bin/buildCollections ./collections/PA
newman run ./collections/PA/generated/policyChangeEvents.json -e $ENV_PATH

echo "Running Policy Change Events Collection - NE"
../../bin/buildCollections ./collections/NE
newman run ./collections/NE/generated/policyChangeEvents.json -e $ENV_PATH

echo "Running Policy Change Events Collection - IN"
../../bin/buildCollections ./collections/IN
newman run ./collections/IN/generated/policyChangeEvents.json -e $ENV_PATH

echo "Running Policy Change Events Collection - MO"
../../bin/buildCollections ./collections/MO
newman run ./collections/MO/generated/policyChangeEvents.json -e $ENV_PATH

echo "Running Policy Change Events Collection - MD"
../../bin/buildCollections ./collections/MD
newman run ./collections/MD/generated/policyChangeEvents.json -e $ENV_PATH

