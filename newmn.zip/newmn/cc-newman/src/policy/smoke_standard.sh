#!/usr/bin/env bash
: "${1?"Usage: $0 env_json_path"}"
ENV_PATH=$1

# NOTE: this flow might be outdated, use smoke_policychanges instead

set -euo pipefail

./bin/buildCollections

pushd ./src/policy || exit

echo "Binding Policy"

newman run ./collections/PA/generated/bindRatedPolicy.json -e $ENV_PATH

echo "Edit Coverages"

newman run ./collections/PA/generated/editCoverages.json -e $ENV_PATH

echo "Add Driver"

newman run ./collections/PA/generated/addDriver.json -e $ENV_PATH

echo "Add Vehicle"

newman run ./collections/PA/generated/addVehicle.json -e $ENV_PATH

echo "Remove Vehicle"

newman run ./collections/PA/generated/removeVehicle.json -e $ENV_PATH

echo "Update Effective Date"

newman run ./collections/PA/generated/updateEffectiveDate.json -e $ENV_PATH

echo "CC Initiated Cancellation Reason 003"

newman run ./collections/PA/generated/insuredCancelVoid.json -e $ENV_PATH

echo "Customer Initiated Cancellation"

newman run ./collections/PA/generated/customerCancel.json -e $ENV_PATH
