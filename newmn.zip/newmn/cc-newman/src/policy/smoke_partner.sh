#!/bin/bash

./src/policy/smoke_policychanges.sh ./env/partnerSystemAdmin.json
# ./src/policy/smoke_standard.sh ./env/partnerSystemAdmin.json