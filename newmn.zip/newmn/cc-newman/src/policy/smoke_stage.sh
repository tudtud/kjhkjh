#!/bin/bash

./src/policy/smoke_policychanges.sh ./env/stagingSystemAdmin.json
# ./src/policy/smoke_standard.sh ./env/stagingSystemAdmin.json