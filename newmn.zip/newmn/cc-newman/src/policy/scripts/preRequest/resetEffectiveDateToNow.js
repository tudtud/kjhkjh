const moment = require('moment');
const effectiveDate = moment().subtract(0, 'M').subtract(0, 'day');

postman.setEnvironmentVariable(
  'effectiveDate',
  effectiveDate.utcOffset('-06:00').format('YYYY-MM-DD')
);
postman.setEnvironmentVariable(
  'effectiveDateTime',
  effectiveDate.utcOffset('-06:00').startOf('day').format()
);
