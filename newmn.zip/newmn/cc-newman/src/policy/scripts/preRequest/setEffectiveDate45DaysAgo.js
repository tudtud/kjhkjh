//TODO: Break this out
const uuid = require('uuid');
pm.environment.set('primaryDriverId', uuid.v4());
pm.environment.set('vehicleId', uuid.v4());

const moment = require('moment');
const effectiveDate = moment().subtract(1, 'M').subtract(15, 'day');

postman.setEnvironmentVariable(
  'effectiveDate',
  effectiveDate.utcOffset('-06:00').format('YYYY-MM-DD')
);
postman.setEnvironmentVariable(
  'effectiveDateTime',
  effectiveDate.utcOffset('-06:00').startOf('day').format()
);
postman.setEnvironmentVariable(
  'endDate',
  moment(pm.variables.get('effectiveDateTime')).add(6, 'months').format()
);
postman.setEnvironmentVariable('bindDate', effectiveDate.utcOffset('-06:00').format());

// TODO break this out
postman.setEnvironmentVariable('randomNumber', Date.now());
