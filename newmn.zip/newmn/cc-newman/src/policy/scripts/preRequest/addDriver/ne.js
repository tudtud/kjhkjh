const moment = require('moment');
const uuid = require('uuid');
pm.environment.set('updateDriverId', uuid.v4());
postman.setEnvironmentVariable(
  'effectiveDateTimeEndorsement',
  moment(pm.variables.get('effectiveDateTime')).add(5, 'days').format()
);
