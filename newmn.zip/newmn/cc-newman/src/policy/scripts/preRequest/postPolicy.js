console.log(responseBody);

var jsonData = pm.response.json();

postman.setEnvironmentVariable('policyId', jsonData.policy.id);

postman.setEnvironmentVariable('policyNumber', jsonData.policy.number);
