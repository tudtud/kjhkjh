pm.test('Status Code', function () {
  pm.response.to.not.be.error;
  pm.response.to.be.json;
  pm.response.to.have.status(200);
});
