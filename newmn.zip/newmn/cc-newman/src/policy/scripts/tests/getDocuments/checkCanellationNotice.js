var jsonData = pm.response.json();
if (pm.response.status.code !== 200) {
  console.log(jsonData);
}

pm.test('Status code is 200', function () {
  pm.response.to.have.status(200);
});

pm.test('Policy Cancellation Notice document exists for the policy', function () {
  pm.expect(pm.response.text()).to.include('Policy Cancellation Notice');
});
