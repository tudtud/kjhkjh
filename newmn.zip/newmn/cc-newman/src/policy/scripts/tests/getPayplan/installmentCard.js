var jsonData = pm.response.json();
if (pm.response.status.code !== 200) {
  console.log(jsonData);
}

var installmentPayCCIndex = 2;

postman.setEnvironmentVariable('payPlanId', jsonData.plans[installmentPayCCIndex].planId);

postman.setEnvironmentVariable(
  'paymentPlanDef',
  JSON.stringify(jsonData.plans[installmentPayCCIndex])
);
