var jsonData = pm.response.json();
if (pm.response.status.code && pm.response.status.code !== 200) {
  console.log(jsonData);
}

postman.setEnvironmentVariable('rateId', jsonData.rateId);

postman.setEnvironmentVariable('discounts', JSON.stringify(jsonData.discountSummary.discounts));
postman.setEnvironmentVariable('alternatePremiums', JSON.stringify(jsonData.alternatePremiums));

postman.setEnvironmentVariable('vehicleId', jsonData.vehicleRatings[0].id);

postman.setEnvironmentVariable('premium', jsonData.totalPremium);

parseInt(
  postman.setEnvironmentVariable(
    'um',
    parseFloat(JSON.stringify(jsonData.vehicleRatings[0].coverageRatings[0].premium))
  )
);

postman.setEnvironmentVariable(
  'pd',
  parseFloat(JSON.stringify(jsonData.vehicleRatings[0].coverageRatings[1].premium))
);
postman.setEnvironmentVariable(
  'fpb',
  parseFloat(JSON.stringify(jsonData.vehicleRatings[0].coverageRatings[2].premium))
);
postman.setEnvironmentVariable(
  'bi',
  parseFloat(JSON.stringify(jsonData.vehicleRatings[0].coverageRatings[3].premium))
);
postman.setEnvironmentVariable(
  'uim',
  parseFloat(JSON.stringify(jsonData.vehicleRatings[0].coverageRatings[4].premium))
);
postman.setEnvironmentVariable(
  'at',
  parseFloat(JSON.stringify(jsonData.vehicleRatings[0].coverageRatings[5].premium))
);
postman.setEnvironmentVariable(
  'coll',
  parseFloat(JSON.stringify(jsonData.vehicleRatings[0].coverageRatings[6].premium))
);
postman.setEnvironmentVariable(
  'comp',
  parseFloat(JSON.stringify(jsonData.vehicleRatings[0].coverageRatings[7].premium))
);
postman.setEnvironmentVariable(
  'ra',
  parseFloat(JSON.stringify(jsonData.vehicleRatings[0].coverageRatings[8].premium))
);
