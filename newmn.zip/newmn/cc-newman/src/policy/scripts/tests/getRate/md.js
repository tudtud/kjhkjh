var jsonData = pm.response.json();
if (pm.response.status.code && pm.response.status.code && pm.response.status.code !== 200) {
  console.log(jsonData);
}

postman.setEnvironmentVariable('rateId', jsonData.rateId);

postman.setEnvironmentVariable('vehicleId', jsonData.vehicleRatings[0].id);

postman.setEnvironmentVariable('premium', jsonData.totalPremium);

postman.setEnvironmentVariable(
  'pd',
  parseFloat(JSON.stringify(jsonData.vehicleRatings[0].coverageRatings[0].premium))
);

parseInt(
  postman.setEnvironmentVariable(
    'uium',
    parseFloat(JSON.stringify(jsonData.vehicleRatings[0].coverageRatings[1].premium))
  )
);

postman.setEnvironmentVariable(
  'pip',
  parseFloat(JSON.stringify(jsonData.vehicleRatings[0].coverageRatings[2].premium))
);

postman.setEnvironmentVariable(
  'bi',
  parseFloat(JSON.stringify(jsonData.vehicleRatings[0].coverageRatings[3].premium))
);

postman.setEnvironmentVariable(
  'umpd',
  parseFloat(JSON.stringify(jsonData.vehicleRatings[0].coverageRatings[4].premium))
);

postman.setEnvironmentVariable(
  'at',
  parseFloat(JSON.stringify(jsonData.vehicleRatings[0].coverageRatings[5].premium))
);

postman.setEnvironmentVariable(
  'coll',
  parseFloat(JSON.stringify(jsonData.vehicleRatings[0].coverageRatings[6].premium))
);

postman.setEnvironmentVariable(
  'comp',
  parseFloat(JSON.stringify(jsonData.vehicleRatings[0].coverageRatings[7].premium))
);

postman.setEnvironmentVariable(
  'ra',
  parseFloat(JSON.stringify(jsonData.vehicleRatings[0].coverageRatings[8].premium))
);

postman.setEnvironmentVariable('alternatePremimums', JSON.stringify(jsonData.alternatePremiums));
