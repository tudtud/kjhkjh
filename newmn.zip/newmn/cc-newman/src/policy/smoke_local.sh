#!/bin/bash

# NOTE: the local environment should probably be identical to stagingSystemAdmin with the only
#       difference being policyApiHost=http://localhost:1338 (and any other locally running services)
#       if you are getting more failures than expected, try overwriting

./src/policy/smoke_policychanges.sh ./env/localToStagingSysAdmin.json
# ./src/policy/smoke_standard.sh ./env/localToStagingSysAdmin.json