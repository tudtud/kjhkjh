const newman = require('newman');
const env = process.env.ENV || 'staging';
const fs = require('fs');

async function postman(collection, env, reporter = 'cli') {
  await newman
    .run({
      collection: require(collection),
      reporters: reporter,
      environment: require(env),
    })

    // Log PolicyID from Postman Summary object
    .on('done', async function (err, summary) {
      if (err || summary.error) {
        console.error('collection run encountered an error.');
      } else {
        // find object where one of the keys = policyId
        const policyIdObj = (id_object) =>
          id_object.filter((obj) => obj.key === 'policyId').map((obj) => obj.value);

        const policyId = await JSON.stringify(policyIdObj(summary.environment.values)).slice(2, -2);

        console.log(policyId);
        // Append policy IDs to file
        const logStream = fs.createWriteStream('./src/policy/tests/partner-policyIds.csv', {
          flags: 'a',
        });
        logStream.write(`${policyId},\n`);
        return policyId;
      }
    });
}

const state = 'PA' || process.env.STATE;
const environment = `../env/${env}SystemAdmin.json`;

postman(`../collections/${state}/generated/editCoverages.json`, environment);

postman(`../collections/${state}/generated/bindRatedPolicyBackdated.json`, environment);

postman(`../collections/${state}/generated/addVehicle.json`, environment);

postman(`../collections/${state}/generated/addDriver.json`, environment);

postman(`../collections/${state}/generated/reinstatement.json`, environment);
