const newman = require('newman');
const env = process.env.ENV || 'uat';
const fs = require('fs');

async function postman(collection, env, reporter = 'cli') {
  await newman
    .run({
      collection: require(collection),
      reporters: reporter,
      environment: require(env),
    })

    // Log PolicyID from Postman Summary object
    .on('done', async function (err, summary) {
      if (err || summary.error) {
        console.error('collection run encountered an error.');
      } else {
        // find object where one of the keys = policyId
        const policyIdObj = (id_object) =>
          id_object.filter((obj) => obj.key === 'policyId').map((obj) => obj.value);

        const policyId = await JSON.stringify(policyIdObj(summary.environment.values)).slice(2, -2);

        console.log(policyId);
        // Append policy IDs to file
        const logStream = fs.createWriteStream('./src/policy/tests/GA-UAT-policyIds.csv', {
          flags: 'a',
        });
        logStream.write(`'${policyId}',\n`);
        return policyId;
      }
    });
}

postman('../collections/GA/generated/bind.json', `../env/${env}SystemAdmin.json`);

//for i in {1..50}; do node ./src/policy/tests/writeIdsToFile.js; done
